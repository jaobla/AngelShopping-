<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informe os seus Dados</title>
    <link rel="stylesheet" 
        type="text/css"
        href="css/style_pag-info.css">
</head>
<body>
    <div class="Center">       
        <h2 style="text-align:center;"></h1style>Informe Seus Dados<br>
             
        <h5> Nome:<input type="text" placeholder="Nome">  <input type="text" placeholder="Sobrenome"> <br>
             Telle :<input type="text" placeholder="(00) 0000-0000"><br> 
             CPF : <input type="text" placeholder="000.000.0000000-00"><br>
             Rua : <input type="text" placeholder="xxxxxx"> Nº :<input type="text" placeholder="xxxxx"><br>
             CEP : <input type="text" placeholder="00000-000"><br>    
            </h5>
        <h5 style="text-align:center;"> 
            Cidade:<input type="text" placeholder="xxxxxxxx"><br>
            Estado:<input type="text" placeholder="xxxxxxxx"><br> <br> 
          <button type="submit" onclick="javascript: location.href='Info_dados.html';" >Salvar</button>   
        </h5>    
                     
    </div>
</body>
</html>