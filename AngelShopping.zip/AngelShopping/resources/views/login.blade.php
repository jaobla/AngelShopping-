<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faça o Login</title>
    <script src="./js/index.js" defer></script>
    <link rel="stylesheet" 
        type="text/css"
        href="css/style_pag.css">
</head>
<body> 
     
    <div class="Center">        
        <h2  style="text-align:center;"></h1style>Login<br>
        <br>
         <input type="text" placeholder="Nome de usuário ou e-mail">
        <br>
        <input type="password" placeholder="Senha">
         <br>
         
            <input type="checkbox" value="Remember"> Lembrar Senha 
        <br>
        <br>
            <button type="submit" onclick="javascript: location.href='/home';" >Entrar</button>
            <br>
            <h5  style="text-align:center;"> Não tem uma conta?
            <br>
                <a href="/cadastrar"> Cadastre-se</a>
                <br>
            </h5>
                <h5  style="text-align:center;"> 
            </h5>
           
    </div>
</body>
</html>