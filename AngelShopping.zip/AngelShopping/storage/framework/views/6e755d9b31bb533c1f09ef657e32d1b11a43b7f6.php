<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>AngelShopping</title>
  </head>

    <script async src="https://cdn.jsdelivr.net/npm/es-module-shims@1/dist/es-module-shims.min.js" crossorigin="anonymous"></script>
    <script type="importmap">
    {
      "imports": {
        "@popperjs/core": "https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js",
        "bootstrap": "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.esm.min.js"
      }
    }
    </script>
    <script type="module">
      import * as bootstrap from 'bootstrap'

      new bootstrap.Popover(document.getElementById('popoverButton'))
    </script>
<body>  
    <nav class="navbar border-bottom" style="background-color: #FFFFFF;">
        <div class="container-fluid">
          <a class="navbar-brand" href="#"><img src="/storage/img/Logoo_AngelShopping.png" alt="Logo_AngelShopping" width="250" height="100" class="d-inline-block align-text-top"></a>
          <form class="d-flex w-50 p-2" role="search">
            <input class="form-control me-2" type="search" placeholder="Hey, o que você está procurando?" aria-label="Hey, o que você está procurando?">
            <button class="btn btn-outline-info btn btn-info btn-sm" type="submit"><h1 class="text-hide" style="background-image: url('/storage/img/lupa.png'); width: 40px; height: 40px; "></h1></button>
          </form>
          <a class="navbar-brand" href="#"><img src="/storage/img/Coração.png" alt="Favoritos" width="30" height="30" class="d-inline-block align-text-top"></a>
          <a class="navbar-brand" href="#"><img src="/storage/img/Sacola.png" alt="Sacola" width="30" height="30" class="d-inline-block align-text-top"></a>
          <a class="navbar-brand" href="#"><img src="/storage/img/Login.png" alt="Login" width="30" height="30" class="d-inline-block align-text-top"></a>
          <a class="nav-link text-info" href="/login">Login</a>
          <a class="nav-link text-info" href="/cadastrar">Cadastrar</a>
          <li class="nav-item">
            <nav class="navbar navbar-expand-lg" style="background-color: #FFFFFF;">
              <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav me-auto mb- mb-lg-0">
                  <p class="text-center">
                  <li class="nav-item">
                      <a class="nav-link active text-center text-white" aria-current="page" href="#">....................................................................</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active text-center text-info" aria-current="page" href="/lojas"><img src="/storage/img/lojas.png" alt="Lojas" width="20" height="20" class="d-inline-block align-text-top"> Lojas</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active text-center text-white" aria-current="page" href="#">..............</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link active text-center text-info" aria-current="page" href="/cinema">   <img src="/storage/img/cinema.png" alt="cinema" width="20" height="20" class="d-inline-block align-text-top">     Cinema</a>                    
                    </li>
                    <li class="nav-item">
                      <a class="text-center text-white" aria-current="page" href="#">.............</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active text-center text-info" aria-current="page" href="/livraria">   <img src="/storage/img/livraria.png" alt="Livraria" width="20" height="20" class="d-inline-block align-text-top">    Livraria</a>                    
                    </li>
                    <li class="nav-item">
                      <a class="text-center text-white" aria-current="page" href="#">..............</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active text-center text-info" aria-current="page" href="/lazer">   <img src="/storage/img/lazer.png" alt="Lazer" width="20" height="20" class="d-inline-block align-text-top">   Lazer</a>                    
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active text-center text-white" aria-current="page" href="#">..............</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link active text-center text-info" aria-current="page" href="/gastronomia">   <img src="/storage/img/gastronomia.png" alt="Gastronomia" width="20" height="20" class="d-inline-block align-text-top">   Gastronomia</a>                    
                    </li>
                  </p>
                  </ul>
                </div>
              </div>
            </nav>      
    </nav>
    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="3" aria-label="Slide 4"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="/storage/img/1.png" height="300" width="300" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="/storage/img/2.png" height="300" width="300" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="/storage/img/3.png" height="300" width="300" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="/storage/img/4.png" height="300" width="300" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
  <div class="text-center">
    <img src="/storage/img/divulgacao.png" class="rounded" alt="..." height="100" width="600">
  </div>
</body>
</html><?php /**PATH C:\laravel\AngelShopping\resources\views/home.blade.php ENDPATH**/ ?>