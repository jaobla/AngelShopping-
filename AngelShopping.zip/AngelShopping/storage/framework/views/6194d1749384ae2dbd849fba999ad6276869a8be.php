<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastre-se</title>
    <script src="./js/index.js" defer></script>
    <link rel="stylesheet" 
        type="text/css"
        href="css/style_pag.css">
</head>
<body>
    <div class="Center">
        
        <h2 style="text-align:center;"></h1style>Cadastre-se<br>
        <br>  
         <input type="text" placeholder="Nome de usuário ou e-mail">
        <br>
        <input type="password" placeholder="Senha">
         <br>
        <input type="password" placeholder="Confirme a Senha">
        <br>
            <input id="mostrar" type="checkbox" value="Remember">Mostrar Senha</input>
        <br>
        <br>
            <button type="submit" onclick="javascript: location.href='/dados'" >Continuar</button>            
    </div>
</body>
</html><?php /**PATH C:\laravel\AngelShopping\resources\views/cadastrar.blade.php ENDPATH**/ ?>