<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});
Route::get('/home', function () {
    return view('home');
});
Route::get('/login', function () {
    return view('login');
});
Route::get('/cadastrar', function () {
    return view('cadastrar');
});
Route::get('/dados', function () {
    return view('dados');
});
Route::get('/lojas', function () {
    return view('lojas');
});
Route::get('/livraria', function () {
    return view('livraria');
});
Route::get('/cinema', function () {
    return view('cinema');
});
Route::get('/lazer', function () {
    return view('lazer');
});
Route::get('/gastronomia', function () {
    return view('gastronomia');
});
